# Los Vaqueiros

Código do site publicado em https://lpaas.site/los-vaqueiros, em HTML, CSS e um pouco de JavaScript. Não precisa instalar nada.

## Como abrir

1. Descompacte esta pasta.
2. Dê dois cliques em `index.html` para ver no navegador.
3. Para editar, abra a pasta no VS Code (Arquivo → Abrir pasta). A extensão **Live Server** recarrega a página a cada alteração.

## O que tem aqui

- `index.html` — Home
- `assets/styles.css` — todo o visual (cores, fontes, espaçamentos)
- `assets/site.js` — animação de entrada dos blocos, menu do celular e perguntas frequentes
- `assets/img/` e `assets/fonts/` — imagens e fontes do site

## Publicar em outro lugar

Envie a pasta inteira para qualquer hospedagem de site estático: Netlify (arraste a pasta em app.netlify.com/drop), Vercel, GitHub Pages, Hostinger ou o FTP da sua hospedagem.

## Limitações desta versão

- Os efeitos feitos em 3D, shader ou canvas aparecem como imagem parada, e algumas animações mais elaboradas viram uma entrada simples.
- Formulários de contato não enviam mais para o seu painel. Troque o `action` do `<form>` por um serviço como Formspree ou Getform.
- Quer o site idêntico, com todas as animações? Baixe a versão **Projeto Next.js**.
