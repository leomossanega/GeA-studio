(function () {
  "use strict";

  // Acordeões, FAQ e menu do celular.
  document.addEventListener("click", function (event) {
    var button = event.target.closest && event.target.closest("button[aria-expanded]");
    if (!button) return;
    var open = button.getAttribute("aria-expanded") !== "true";
    button.setAttribute("aria-expanded", String(open));
    var id = button.getAttribute("aria-controls");
    var panel = id ? document.getElementById(id) : null;
    if (panel) {
      panel.hidden = !open;
      return;
    }
    var next = button.nextElementSibling;
    if (next && next.className.indexOf("grid-rows-") !== -1) {
      next.className = next.className.replace(open ? "grid-rows-[0fr]" : "grid-rows-[1fr]", open ? "grid-rows-[1fr]" : "grid-rows-[0fr]");
    }
  });

  // Fecha o menu do celular ao tocar num link dele.
  document.addEventListener("click", function (event) {
    var link = event.target.closest && event.target.closest("a");
    var panel = link && link.closest("[id]");
    if (!panel || !panel.id) return;
    var button = document.querySelector('button[aria-controls="' + panel.id + '"]');
    if (button && panel.querySelector("nav")) {
      button.setAttribute("aria-expanded", "false");
      panel.hidden = true;
    }
  });

  var items = Array.prototype.slice.call(document.querySelectorAll("[data-reveal]"));
  var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (!items.length || reduce || !("IntersectionObserver" in window)) return;

  var vh = window.innerHeight;
  var hidden = items.filter(function (el) {
    var r = el.getBoundingClientRect();
    return !(r.top < vh * 0.95 && r.bottom > 0);
  });
  hidden.forEach(function (el) { el.classList.add("lp-x-hidden"); });

  function show(el) {
    el.classList.add("lp-x-in");
    observer.unobserve(el);
  }
  var observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) { if (entry.isIntersecting) show(entry.target); });
  }, { rootMargin: "0px 0px -5% 0px" });
  hidden.forEach(function (el) { observer.observe(el); });

  // Rede de segurança: na tela e ainda invisível por mais de 1,5 s → aparece.
  var seen = new Map();
  setInterval(function () {
    var now = Date.now();
    var h = window.innerHeight;
    hidden.forEach(function (el) {
      if (el.classList.contains("lp-x-in")) return;
      var r = el.getBoundingClientRect();
      if (r.top < h * 0.7 && r.bottom > 0) {
        if (!seen.has(el)) seen.set(el, now);
        else if (now - seen.get(el) > 1500) show(el);
      } else {
        seen.delete(el);
      }
    });
  }, 500);
})();
